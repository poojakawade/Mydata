package com.digitalbook.clients;


import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.digitalbook.models.Book;
import com.digitalbook.models.Message;
import com.digitalbook.models.Subscribe;

import feign.Headers;

@FeignClient(name="bookservice",url="localhost:9191")
public interface BookServiceClient {
	
	@GetMapping("/api/v1/digitalbooks/books")
	List<Book> getAllBooks();
	
	@GetMapping("/api/v1/digitalbooks/books/searchbybooks")
	List<Book> getBooks(@RequestParam String  category, @RequestParam String author,
			@RequestParam double price,@RequestParam String publisher);
	
	@PostMapping("/api/v1/digitalbooks/subscribe")
	Subscribe subscribeBook(Subscribe subscribeReader);
	
	//@GetMapping("/api/v1/digitalbooks/getbooksbyemailID")
	@RequestMapping(method = RequestMethod.GET, value = "/api/v1/digitalbooks/{emailID}/books")
	List<Book> getBooksbyemailID(@PathVariable String emailID);
	
	@RequestMapping(method = RequestMethod.GET, value = "/api/v1/digitalbooks/{emailID}/books/{bookId}")
	List<Book> getBooksbyemailIDnbookID(@PathVariable String emailID,@PathVariable int bookId);
	
	@RequestMapping(method = RequestMethod.GET, value = "/api/v1/digitalbooks/{emailID}/bookss")
	List<Book> getBooksbypayId(@PathVariable String emailID,@RequestParam int payId);
	
	@RequestMapping(method = RequestMethod.GET, value = "/api/v1/digitalbooks/{emailID}/books/{bookId}/refund")
	Message getRefund(@PathVariable String emailID,@PathVariable int bookId);
}
 