package com.digitalbook.controllers;

import java.util.List;

import org.hibernate.internal.CriteriaImpl.Subcriteria;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.digitalbook.clients.BookServiceClient;
import com.digitalbook.models.Book;
import com.digitalbook.models.Subscribe;

@RestController
@RequestMapping("/api/v1/digitalbooks/books")
@CrossOrigin("*")
public class ReaderController {

	@Autowired
	private BookServiceClient bookServiceClient;

	@GetMapping("/searchbooks")
	public List<Book> getAllBooks() {
		return bookServiceClient.getAllBooks();
	}

	@GetMapping("/search")
	public List<Book> getBooks(@RequestParam String category, @RequestParam String author, @RequestParam double price,
			@RequestParam String publisher) {
		return bookServiceClient.getBooks(category, author, price, publisher);
	}

	@PostMapping("/buy")
	public Subscribe subscribeBook(@RequestBody Subscribe subscribeReader) {
		return bookServiceClient.subscribeBook(subscribeReader);
	}

}
