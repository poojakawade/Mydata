package com.digitalbook.clients;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

import com.digitalbook.models.Book;

import feign.Headers;

@FeignClient(name = "bookservice", url = "localhost:9191")
public interface BookServiceClient {

	@PostMapping("/api/v1/digitalbooks/savebooks")
	@Headers("Content-Type: application/json")
	Book SaveBook(Book book);

	@PutMapping("/api/v1/digitalbooks/update")
	Book updateBook(Book book);

	@DeleteMapping("/api/v1/digitalbooks/books/{bookId}")
	public void deleteBook(@PathVariable int bookId);

	@GetMapping("/api/v1/digitalbooks/getBooks/{authorId}")
	public List<Book> getAllAuthorBooks(@PathVariable int authorId); 

}
