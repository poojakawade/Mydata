package com.digitalbook.entities;

public enum ERole {
  ROLE_READER,
  ROLE_AUTHOR
}