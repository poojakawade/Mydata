package com.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import com.digitalbook.DigitalBookAuthorApplication;

@SpringBootTest(classes = DigitalBookAuthorApplication.class)
class DigitalBookAuthorApplicationTests {

	@Test
	void contextLoads() {
	}

}
