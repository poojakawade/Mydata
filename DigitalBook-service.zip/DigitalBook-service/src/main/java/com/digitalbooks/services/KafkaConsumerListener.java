//package com.digitalbooks.services;
//
//import java.util.List;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.kafka.annotation.KafkaListener;
//import org.springframework.stereotype.Service;
//
//import com.digitalbook.models.Book;
//import com.digitalbooks.repositories.BookServiceRepository;
//import com.digitalbooks.utils.EmailUtil;
//
//@Service
//public class KafkaConsumerListener {
//	
//	@Autowired
//	private BookServiceRepository repo;
//	
//	@Autowired
//	private EmailUtil util;
//	
//	String email=null;
//	String subject=null;
//	String text =null;
//
//    private static final String TOPIC = "kafka-topic";
//
//    @KafkaListener(topics = TOPIC, groupId="group_id", containerFactory = "userKafkaListenerFactory")
//    public void consumeJson(Book book) {
//        System.out.println("Consumed JSON Message: " + book);
//        System.out.println("Consumed JSON Message: book Id: " + book.getId());
//        System.out.println("Consumed JSON Message: book Active Status: " + book.getStatus());
//        List<String> emailIds = repo.getauthemailIds(book.getId());
//        System.out.println("Consumed JSON Message: Author emailIds: " + emailIds);
//
//        if(book.getStatus().equalsIgnoreCase("InActive")) {
//        for (String emails : emailIds)   
//        {  
//        //prints the elements of the List  
//        	System.out.println(emails);
//        	email = emails;
//        	subject = "The book Named "+book.getTitle()+" has been blocked by author ";
//        	text = "Your subscribed "+book.getTitle()+" book has been blocked by author. Book is unavailable now. Kindly wait for further notifications.";
//            System.out.println("Consumed JSON Message: " + email );
//            System.out.println("Consumed JSON Message: " + subject );
//            System.out.println("Consumed JSON Message: " + text );
//
//        	util.send(email, subject, text);
//        }  
//        }
//
//        
//    }
//    
//}