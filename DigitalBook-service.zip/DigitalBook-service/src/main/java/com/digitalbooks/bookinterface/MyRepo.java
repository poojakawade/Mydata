package com.digitalbooks.bookinterface;

import org.springframework.data.repository.CrudRepository;

import com.digitalbooks.entities.Book;

public interface MyRepo extends CrudRepository<Book,Integer> {
	// List<T> findAll();
//   T findById(P id);
//   T save(T m);
//   T delete(P id);
	

}
