package com.demo.handler;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;
import com.amazonaws.services.lambda.runtime.events.APIGatewayProxyRequestEvent;
import com.amazonaws.services.lambda.runtime.events.APIGatewayProxyResponseEvent;
import com.demo.models.Book;
import com.demo.models.Movie;

public class MyLambdaHandler implements RequestHandler<APIGatewayProxyRequestEvent, APIGatewayProxyResponseEvent> {

    List<Book> books = Arrays.asList(new Book("Superman", "Comic", 90, "Tony", "ReadVision Publisher", "Comic Book", "Active"),
    		new Book("Harry Potter", "Comic", 150, "J. K. Rowling", "Bloomsbury Publishing", "Comic Book","Active"),
    		new Book("Twilight", "Comic", 129, "Stephenie Meyer", "Little, Brown and Company","Comic Book", "Active"),
    		new Book("Fairy Tale", "Comic", 160, "Stephen King", "Scribner", "Dark Fantasy", "Active"));
    
  
    
    

    @Override
    public APIGatewayProxyResponseEvent handleRequest(APIGatewayProxyRequestEvent event, Context context) {

        try {
            String inputRating = event.getQueryStringParameters().get("price");
            double price = Double.parseDouble(inputRating);

            List<Book> filterebooks = new ArrayList<>();
            for (Book b : books) {
                if (b.getPrice() >= price) {
                	filterebooks.add(b);
                }
            }

            return new APIGatewayProxyResponseEvent()
                    .withStatusCode(200)
                    .withBody(filterebooks.toString());
        } catch (Exception e) {
            return new APIGatewayProxyResponseEvent()
                    .withStatusCode(200)
                    .withBody(books.toString());

        }
    }

}
