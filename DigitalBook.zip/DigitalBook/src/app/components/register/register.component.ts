import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, NgForm } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { LoginService } from 'src/app/services/login.service';
import { User } from 'src/app/user';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.scss']
})
export class RegisterComponent implements OnInit {

  public user: User[] = [];
  //userForm:FormGroup;

  constructor(private loginservice:LoginService,private router:Router,
    private route:ActivatedRoute) { 
    // this.userForm = new FormGroup({
    //   "username": new FormControl(""),
    //   "email": new FormControl(""),
    //   "password": new FormControl(""),
    //   "roles": new FormControl(""),

    // })
  }

  ngOnInit(): void {
  }

  onsubmit(addForm: NgForm){
    console.log(addForm.value);
    this.loginservice.signUp(addForm.value).subscribe(
      (response:any) => {
        console.log(response);
        //window.location.href="/login"
        this.router.navigate(['/login']);
        //addForm.reset();
      },
      (error: HttpErrorResponse) => {
        alert(error.message);
        addForm.reset();
      }
    );
    //console.log("Form is Submitted")
    // if((this.credentials.username!='' && this.credentials.password!='') && (this.credentials.username!=null && this.credentials.password!=null) ){

    //   console.log("we have to submit the form");
    //   this.loginservice.generateToken(this.credentials).subscribe((response:any)=>{
    //     console.log(response);
    //     console.log(response.accessToken);
    //     console.log(response.id);
    //     this.loginservice.loginUser(response.accessToken)
    //     this.loginservice.setId(response.id)
    //     window.location.href="/dashboard"
    //   },
    //   error=>{
    //     console.log(error);
        
    //   }   )
    // }else{
    //   console.log("Fields are empty");
    // }
  }
}
