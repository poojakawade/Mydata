import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { JwtResponse } from 'src/app/JwtResponse';
import { LoginService } from 'src/app/services/login.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  jwtResponse: JwtResponse;
  credentials={
    username:'',
    password:''

  }
  constructor(private loginservice:LoginService,private router:Router,
    private route:ActivatedRoute) { }

  ngOnInit(): void {
  }

  onsubmit(){
    //console.log("Form is Submitted")
    if((this.credentials.username!='' && this.credentials.password!='') && (this.credentials.username!=null && this.credentials.password!=null) ){

      console.log("we have to submit the form");
      this.loginservice.generateToken(this.credentials).subscribe((response:any)=>{
        console.log(response);
        console.log(response.accessToken);
        console.log(response.id);
        this.loginservice.loginUser(response.accessToken)
        //localStorage.setItem("token",response.accessToken);
        this.loginservice.setId(response.id)
        //window.location.href="/dashboard"
        this.router.navigate(['/dashboard']);
      },
      error=>{
        console.log(error);
        
      }   )
    }else{
      console.log("Fields are empty");
    }
  }

}
