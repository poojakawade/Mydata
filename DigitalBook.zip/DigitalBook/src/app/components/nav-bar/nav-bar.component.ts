import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Book } from 'src/app/book';
import { BookService } from 'src/app/services/book.service';
import { LoginService } from 'src/app/services/login.service';

@Component({
  selector: 'app-nav-bar',
  templateUrl: './nav-bar.component.html',
  styleUrls: ['./nav-bar.component.scss']
})
export class NavBarComponent implements OnInit {

  public loggedIn=true;
  public books: Book[] = [];

  constructor(private loginService: LoginService,private bookService: BookService,private router:Router,
    private route:ActivatedRoute) { 
      //this.loggedIn=this.loginService.isLoggedIn();
      //console.log("constructor calling:"+this.loggedIn);
    }

  ngOnInit(): void {
    this.loggedIn=this.loginService.isLoggedIn()
    //location.reload()
    console.log(this.loggedIn);
    this.getBooks();
  }

  logoutUser(){
    this.loginService.logout()
    //location.reload()
    this.router.navigate(['/login']);
  }

  public getBooks():void{
    this.bookService.getBooks().subscribe(
      (Response:Book[])=>{
        this.books=Response;

      },
      (error:HttpErrorResponse)=>{
        alert(error.message);
        
      } 
    );
  }

  // public searchBooks(key: string): void {
  //   console.log(key);
  //   const results: Book[] = [];
  //   for (const bookss of this.books) {
  //     console.log(key);
  //     if (bookss.category.toLowerCase().indexOf(key.toLowerCase()) !== -1
  //     || bookss.author.toLowerCase().indexOf(key.toLowerCase()) !== -1
  //     //|| book.price.indexOf(key.toLowerCase()) !== -1
  //     || bookss.publisher.toLowerCase().indexOf(key.toLowerCase()) !== -1) {
  //       console.log(key);
  //       results.push(bookss);
  //       console.log(results);
  //     }
  //   }
  //   this.books = results;
  //   console.log( this.books);
  //   if (results.length === 0 || !key) {
  //     this.getBooks();
  //   }
  // }

}
