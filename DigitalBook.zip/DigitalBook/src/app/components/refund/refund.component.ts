import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Book } from 'src/app/book';
import { Message } from 'src/app/message';
import { BookService } from 'src/app/services/book.service';

@Component({
  selector: 'app-refund',
  templateUrl: './refund.component.html',
  styleUrls: ['./refund.component.scss']
})
export class RefundComponent implements OnInit {

  public books: Book[] = [];
  emailId:'';
  bookId:'';
  constructor(private bookService: BookService,private router:Router,
    private route:ActivatedRoute) { }

  ngOnInit(): void {
  }

  onRefund(){
    console.log("Form is Submitted"+this.emailId+this.bookId+this.bookId)
    if((this.emailId!='' && this.emailId!=null) && ((this.bookId!=''  && this.bookId!=null) )){
      this.bookService.getRefundsbyEmailIdnbookId(this.emailId,this.bookId).subscribe((response:Message)=>{
        console.log((response.message));
        //this.books=response
        alert(response.message);
        //window.location.href="/reader"
        this.router.navigate(['/reader']);

      },
      error=>{
          console.log(error);
          
      }   )
   
  }else{
    console.log("Fields are empty")
  }
}

}
