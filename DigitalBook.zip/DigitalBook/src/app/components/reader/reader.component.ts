import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Book } from 'src/app/book';
import { BookService } from 'src/app/services/book.service';

@Component({
  selector: 'app-reader',
  templateUrl: './reader.component.html',
  styleUrls: ['./reader.component.scss']
})
export class ReaderComponent implements OnInit {

  public books: Book[] = [];
  emailId:'';
  bookId:'';
  payId:'';


  constructor(private bookService: BookService) { }

  ngOnInit(): void {
    this.getBooks();
  }

  public getBooks():void{
    this.bookService.getBooks().subscribe(
      (Response:Book[])=>{
        this.books=Response;

      },
      (error:HttpErrorResponse)=>{
        alert(error.message);
        
      } 
    );
  }

  onSearch(){
    console.log("Form is Submitted"+this.emailId+this.bookId+this.payId)
    if((this.emailId!='' && this.emailId!=null) && ((this.bookId==undefined  && this.payId==undefined) ||(this.bookId==''  && this.payId=='') )){
      this.bookService.getBooksbyEmailId(this.emailId).subscribe((response:any)=>{
        console.log(response);
        this.books=response
      },
      error=>{
          console.log(error);
          
      }   )
    }else if((this.emailId!='' && this.emailId!=null)&&(this.bookId!='' && this.bookId!=null) && (this.payId==undefined ||this.payId=='' )){
      this.bookService.getBooksbyEmailIdnBookId(this.emailId,+this.bookId).subscribe((response:any)=>{
        console.log(response);
        this.books=response
      },
      error=>{
          console.log(error);
          
      }   )
    }
    else if((this.emailId!='' && this.emailId!=null)&&(this.payId!='' && this.payId!=null)&& (this.bookId==undefined||this.bookId=='')){
      this.bookService.getBooksbyEmailIdnPayId(this.emailId,+this.payId).subscribe((response:any)=>{
        console.log(response);
        this.books=response
      },
      error=>{
          console.log(error);
          
      }   )
    }
  }
   
}
