import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { User } from '../user';

@Injectable({
  providedIn: 'root'
})
export class LoginService {

  url="http://52.192.210.116:8181/api/v1/digitalbooks/author/auth";

  constructor(private http:HttpClient ) {
  }

  //calling server to generate token
  generateToken(credentials:any): Observable<any>{
      return this.http.post(`${this.url}/signin`,credentials)
  }

  signUp(user:User): Observable<User[]>{
    return this.http.post<User[]>(`${this.url}/signup`,user)
}

  //user login
  loginUser(token: string){
    localStorage.setItem("token",token);
    return true;

  }
  isLoggedIn(){
    let token =localStorage.getItem("token");
    console.log("token isloggedIn: "+token);
    if(token==undefined || token==='' || token==null){
      return false;
    }else{
      return true;
    }
  }

  logout(){
    localStorage.removeItem("token");
    localStorage.removeItem("id");
    return true;
  }

  getToken(){
    return localStorage.getItem("token");
  }

  setId(id: number){
    localStorage.setItem("id",JSON.stringify(id));
    return true;

  }

  getId(){
    return localStorage.getItem("id");

  }
}
